@extends('layout')

@section('menubar')
	@include('sub.menubar')
@endsection

@section('content')
	@include('sub.orgheader', ['active' => 'about'])

	<div class="container py-2">
        <div class="row">
			<div class="col-md-12">
				@if ($org['description'] == '')
					<h1 class="display-4">...</h1>
				@else
					<h1 class="display-4">About</h1>
					<p class="lead">
						{!! nl2br($org['description']) !!}
					</p>
				@endif
			</div>
        </div>
        <div class="row mb-4">
			@php
				$w = $org['Twitter'] && $org['Facebook'] ? 4 : 6;
			@endphp
			<div class="col-md-{{ $w }}">
				<div class="card">
					<div class="card-body">
						<h5 class="card-title mb-4">Stats</h5>
						<div class="card-text" style="height:600px;">
							<table class="table-sm stats-table">
							  <thead>
								<tr>
								  <th scope="col">Dataset</th>
								  <th scope="col">Records</th>
								</tr>
							  </thead>
							  <tbody>
								@foreach($slist as $dsName=>$dsTitle)
									@if($dsName <> 'about')
									  <tr>
										  <th scope="row">{{ $dsTitle }}</th>
										  <td id="stats_{{ $dsName }}"></td>
									  </tr>
								    @endif
								@endforeach
							  </tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			@if($org['Twitter'])
				<div class="col-md-{{ $w }}">
					<div class="card">
						<div class="card-body">
							<h5 class="card-title mb-4">Twitter (profile)</h5>
							<div class="card-text" style="height:600px;">
								<a class="twitter-timeline" data-height="600" href="{{ $org['Twitter'] }}">&nbsp;</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
							</div>
						</div>
					</div>
				</div>
			@endif
			@if($org['Facebook'])
				<div class="col-md-{{ $w }}">
					<div class="card">
						<div class="card-body">
							<h5 class="card-title mb-4">Facebook (page)</h5>
							<div class="card-text" style="height:600px;">
								<aside class="widget--facebook--container">
									<div class="widget-facebook">
									  <iframe id="facebook_iframe" class="facebook_iframe"></iframe>
									</div>
								</aside>
								<style type="text/css">
									.widget--facebook--container {
									  padding: 0px;
									}

									.widget-facebook {
									  height: 600px;
									}

									.widget-facebook .facebook_iframe {
									  border: none;
									}
								</style>
								<script type="text/javascript">
									function setupFBframe(frame) {
									  var container = frame.parentNode;

									  var facebooklink = "{{ $org['Facebook'] }}";

									  var containerWidth = container.offsetWidth;
									  var containerHeight = container.offsetHeight;

									  var src =
										"https://www.facebook.com/plugins/page.php" +
										"?href="+facebooklink+
										"&tabs=timeline" +
										"&width=" +
										containerWidth +
										"&height=" +
										containerHeight +
										"&small_header=true" +
										"&adapt_container_width=true" +
										"&hide_cover=false" +
										"&hide_cta=true" +
										"&show_facepile=true" +
										"&appId";

									  frame.width = containerWidth;
									  frame.height = containerHeight;
									  frame.src = src;
									}

									/* begin Document Ready                                             
									############################################ */

									document.addEventListener('DOMContentLoaded', function() {
									  var facebookIframe = document.querySelector('#facebook_iframe');
									  setupFBframe(facebookIframe);
									 
									  /* begin Window Resize                                            
									  ############################################ */
									  
									  // Why resizeThrottler? See more : https://developer.mozilla.org/ru/docs/Web/Events/resize
									  (function() {
										window.addEventListener("resize", resizeThrottler, false);

										var resizeTimeout;

										function resizeThrottler() {
										  if (!resizeTimeout) {
											resizeTimeout = setTimeout(function() {
											  resizeTimeout = null;
											  actualResizeHandler();
											}, 66);
										  }
										}

										function actualResizeHandler() {
										  document.querySelector('#facebook_iframe').removeAttribute('src');
										  setupFBframe(facebookIframe);
										}
									  })();
									  /* end Window Resize
									  ############################################ */
									});
								</script>
							</div>
						</div>
					</div>
				</div>
			@endif
        </div>
	</div>

	<script>
		function loadstat(dsName, url) {
			$.get(url, function (resp) {
				console.log(resp)
				//jj = $.parseJSON(resp)
				$('#stats_'+dsName).text(resp['rows'][0]['count'])
			})
		}
		
		$(document).ready(function () {
			@foreach(array_keys($slist) as $i=>$dsName)	
				@if($i > 0)
					loadstat("{{ $dsName }}", "{!! str_replace('tablename', $allDS[$dsName]['table'], $url) !!}")
				@endif
			@endforeach		
		})
	</script>
@endsection
